/* Tom Maughan w15016360	*/
int randrange(int from, int to);
float radians(float a);
