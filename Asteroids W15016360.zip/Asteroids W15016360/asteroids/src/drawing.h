/* Jaimine Mistry W15022143	*/
void draw(void);
void gameovertext(void);
void drawmissiles(struct missile *lst);
void shield(void);
void swap_double_buffers(void);
void init_double_buffering(void);
void drawasteroids(struct asteroid *lst);
