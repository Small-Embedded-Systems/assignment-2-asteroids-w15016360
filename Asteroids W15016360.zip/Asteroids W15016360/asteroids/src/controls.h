/* Tom Maughan w15016360	*/
void controls(void);
bool startagain(void);
bool ispressed(enum position p);