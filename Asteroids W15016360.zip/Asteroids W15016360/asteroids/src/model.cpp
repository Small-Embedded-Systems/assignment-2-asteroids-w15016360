/* Jaimine Mistry W15022143	*/
/* Model of Asteroids */
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include "model.h"
#include "utils.h"
#include "asteroids.h"

void physics(void)
{
    
}