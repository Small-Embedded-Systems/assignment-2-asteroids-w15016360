/* Jaimine Mistry W15022143	*/
void controls(void);
bool startagain(void);
bool ispressed(enum position p);