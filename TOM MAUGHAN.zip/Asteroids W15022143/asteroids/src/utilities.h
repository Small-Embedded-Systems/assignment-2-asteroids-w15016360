/* Jaimine Mistry W15022143	*/
int randrange(int from, int to);
float radians(float a);
